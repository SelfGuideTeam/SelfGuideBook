<template>
  <div class="comments">
    <vue-disqus shortname="self-guide-book" :identifier="page_id" url="http://example.com/path"></vue-disqus>
  </div>
</template>

<script>
