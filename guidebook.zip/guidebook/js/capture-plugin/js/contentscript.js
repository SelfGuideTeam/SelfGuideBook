function send(e) {
    chrome.extension.sendMessage(e, function() {})
}

function start() {
    function e(e) {
        if (n !== e.target) {
            "A" == e.target.tagName && $(e.target).attr("href", "javascript:void(0);"), n = e.target, s.top = -window.scrollY, s.left = -window.scrollX;
            for (var t = e.target; t !== document.body;) s.top += t.offsetTop, s.left += t.offsetLeft, t = t.offsetParent;
            s.width = n.offsetWidth, s.height = n.offsetHeight, outline.style.top = s.top - BORDER_THICKNESS + "px", outline.style.left = s.left - BORDER_THICKNESS + "px", outline.style.width = s.width + "px", outline.style.height = s.height + "px", outline.style.pointerEvents = "none", s.top = $(e.target).offset().top - BORDER_THICKNESS, s.left = $(e.target).offset().left - BORDER_THICKNESS
        }
    }

    function t(n) {
        return "IFRAME" == n.target.tagName ? !1 : void("true" === flashSound ? (o(), $(".domElements div").css({
            background: "rgba(255, 255, 255, 0.5)"
        }), setTimeout(function() {
            $(".domElements div").animate({
                background: "rgba(255, 255, 255, 0)"
            }, 200, function() {
                $(".domElements").remove(), document.body.removeEventListener("mousemove", e, !1), document.body.removeEventListener("mouseup", t, !1), setTimeout(function() {
                    send({
                        type: "up",
                        dimensions: s
                    }), setTimeout(function() {
                        window.location.reload()
                    }, 500)
                }, 200)
            })
        }, 100)) : ($(".domElements div").css({
            background: "rgba(255, 255, 255, 0.5)"
        }), setTimeout(function() {
            $(".domElements div").animate({
                background: "rgba(255, 255, 255, 0)"
            }, 200, function() {
                $(".domElements").remove(), document.body.removeEventListener("mousemove", e, !1), document.body.removeEventListener("mouseup", t, !1), setTimeout(function() {
                    send({
                        type: "up",
                        dimensions: s
                    }), setTimeout(function() {
                        window.location.reload()
                    }, 500)
                }, 200)
            })
        }, 100)))
    }

    function o() {
        $("body").append('<audio style="display:none;" controls id="capture-flash"><source src="http://d3jbf8nvvpx3fh.cloudfront.net/voila/_resource/web_extension/sound/capture_click.mp3" type="audio/mpeg"></audio>');
        var e = document.getElementById("capture-flash");
        e.play()
    }
    overlay || (overlay = document.createElement("div"), overlay.className = "domElements", overlay.style.position = "fixed", overlay.style.top = "0px", overlay.style.left = "0px", overlay.style.zIndex = "9999", overlay.style.pointerEvents = "none", outline = document.createElement("div"), outline.style.position = "fixed", outline.style.border = BORDER_THICKNESS + "px solid rgba(175, 83, 205, 1)", outline.style.zIndex = "9999", overlay.appendChild(outline)), overlay.parentNode || (document.body.appendChild(overlay), document.body.addEventListener("mousemove", e, !1), document.body.addEventListener("mouseup", t, !1));
    var n, s = {};
    window.addEventListener("keydown", function(o) {
        o = o || window.event, 27 == o.keyCode && (document.body.removeEventListener("mousemove", e, !1), document.body.removeEventListener("mouseup", t, !1), $(".domElements").remove())
    }, !1)
}

function destroy_DOM() {
    document.body.removeEventListener("mousemove", start.mousemove, !1), document.body.removeEventListener("mouseup", start.mouseup, !1), $(".domElements").remove()
}
var flashSound = "";
chrome.extension.onRequest.addListener(function(e, t, o) {
    "start" === e.type ? (flashSound = e.flashSound, $(".domElements div").css({
        background: "none"
    }), start()) : "destroy" === e.type && destroy_DOM(), o({})
});
var BORDER_THICKNESS = 1,
    overlay, outline, flag = !0;