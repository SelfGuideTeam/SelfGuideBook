var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var body =require('body-parser');
//var firebase = require('firebase');
//var dateFormat = require('dateformat');
//var path =require('path')
//var indexRouter = require('./routes/index');
//var usersRouter = require('./routes/users');
var app = express();
//var config = {
//	      apiKey: "AIzaSyCfGRtTXqUSwxRmm7Djkf6vT_xT3nijqJY",
//	    authDomain: "cloudfirestore-89443.firebaseapp.com",
//	    databaseURL: "https://cloudfirestore-89443.firebaseio.com",
//	    projectId: "cloudfirestore-89443",
//	    storageBucket: "cloudfirestore-89443.appspot.com",
//	    messagingSenderId: "322707861242",
//	    appId: "1:322707861242:web:98839d35a06c6892966343",
//	    measurementId: "G-3N0R1KVRYD"
//	};
//	firebase.initializeApp(config);
//	var db = firebase.firestore();
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(body.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

//app.use('/', indexRouter);
//app.use('/users', usersRouter);
//app.use('/board1',require('./routes/board1'));
app.use('/board2',require('./routes/board2'))

//app.post('/test', function(req, res){
//  console.log('dasdas');
//  db.collection("board").doc(req.query.brdno).onSnapshot(function(doc){
//      console.log("Current data: ");
//      var childData =doc.data();
//      console.log(childDate.brdno);
//      var responseData = {'result':childData.brdno}
//      res.json(responseData);
//      
//      
//  });
//});

//app.use('/board2',require('./routes/board2'));
//app.use('/board4',require('./routes/member'));

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
