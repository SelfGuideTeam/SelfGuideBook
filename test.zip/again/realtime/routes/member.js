var express = require('express');
var router = express.Router();
var firebase = require("firebase");
var crypto = require('crypto');

router.get('/',function(req,res,next){
   res.redirect('userList');
});

var config = {
    apiKey: "AIzaSyCfGRtTXqUSwxRmm7Djkf6vT_xT3nijqJY",
    authDomain: "cloudfirestore-89443.firebaseapp.com",
    databaseURL: "https://cloudfirestore-89443.firebaseio.com",
    projectId: "cloudfirestore-89443",
    storageBucket: "cloudfirestore-89443.appspot.com",
    messagingSenderId: "322707861242",
    appId: "1:322707861242:web:98839d35a06c6892966343",
    measurementId: "G-3N0R1KVRYD"
};
firebase.initializeApp(config);
var db = firebase.firestore();


router.get('/userList', function(req, res, next) {
    db.collection('user').orderBy("userno", "asc").get()
        .then((snapshot) => {
            var rows = [];
            snapshot.forEach((doc) => {
                var childData = doc.data();
                
                rows.push(childData);
            });
            res.render('board4/userList', {rows: rows});
        })
        .catch((err) => {
            console.log('Error getting documents', err);
        });
});
router.get('/userRead', function(req, res, next) {
    db.collection('user').doc(req.query.brdno).get()
        .then((doc) => {
            var childData = doc.data();
            
          
            res.render('board4/userRead', {row: childData});
        });
});

router.get('/joinForm', function(req,res,next){
    if (!req.query.userno) { // new
        res.render('board4/joinForm', {row: ""});
        return;
    }
    
    // update
    db.collection('user').doc(req.query.userno).get()
          .then((doc) => {
              var childData = doc.data();
              res.render('board4/joinForm', {row: childData});
          })
});

 router.post('/memberSave', function(req,res,next){
    var postData = req.body;
    
      var getData = db.collection('user');

      var allemail =getData.get().then(snapshot =>{
        snapshot.forEach(doc =>{
           
       
         var emails = doc.data().m_email;
         if(req.body.m_email == emails){
            res.redirect('joinForm')
           
            }
    }
      );
             
               if (!postData.userno) {  // 새로운 문서 DB에 넣기
                var doc = db.collection("user").doc();
                postData.userno = doc.id;
            
                
                //암호화        
                var hash=crypto.createHash('sha256').update(req.body.m_pass).digest('base64')
                postData.m_pass = hash;
                
        
                doc.set(postData);
                
            } else {                // update
                var doc = db.collection("user").doc(postData.userno);
                doc.update(postData);
                
            }
            res.redirect('userList');
             
        }).catch(err => {
        console.log('Error getting documents', err);
    });
    
    
         
    });

module.exports = router;
