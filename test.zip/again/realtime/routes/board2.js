var express = require('express');
var router = express.Router();
var firebase = require("firebase");
var dateFormat = require('dateformat');
var multer = require('multer');
var path =require('path')
var mime =require('mime')
var fs = require('fs')
var http =require('http')
var json =require('json')
var body =require('body-parser');

var _storage=multer.diskStorage({
    
	destination:function(req,file,cb){
		if(file.mimetype === ('image/png'||'image/jpeg'))
		cb(null,'uploads/img');
		else if(file.mimetype === 'text/plain')
		cb(null,'uploads/txt');
		else if(file.mimetype === 'application/pdf')
		cb(null,'uploads/pdf')
		else
		cb(null,'uploads/etx');
	},
	filename:function(req,file,cb){
            cb(null,file.originalname+'-'+'s');
	}
});
var upload = multer({storage:_storage});

// router.post('/',upload.single('brdfile'),function(req,res,next){
//   console.log(req.file);
//   //파일정보
//    //res.send('UPLOADED'+ req.file.filename)

// })

router.get('/', function(req, res, next) {
    res.redirect('boardList');
});

var config = {
      apiKey: "AIzaSyCfGRtTXqUSwxRmm7Djkf6vT_xT3nijqJY",
    authDomain: "cloudfirestore-89443.firebaseapp.com",
    databaseURL: "https://cloudfirestore-89443.firebaseio.com",
    projectId: "cloudfirestore-89443",
    storageBucket: "cloudfirestore-89443.appspot.com",
    messagingSenderId: "322707861242",
    appId: "1:322707861242:web:98839d35a06c6892966343",
    measurementId: "G-3N0R1KVRYD"
};
firebase.initializeApp(config);
var db = firebase.firestore();
var countries=[];
countries =[]

router.get('/boardList', function(req, res, next) {
	console.log(countries[0]);
     db.collection('board').orderBy("brddate", "desc").get()
         .then((snapshot) => {
             var rows = [];
             snapshot.forEach((doc) => {
                 var childData = doc.data();
                 childData.brddate = dateFormat(childData.brddate, "yyyy-mm-dd");
                 rows.push(childData);
             });
             res.render('board2/boardList', {rows: rows});
         })
         .catch((err) => {
             console.log('Error getting documents', err);
         });
 });
router.get('/boardList1',function(req,res,next){
//     var data =[];
//     data.push(req.query);
	
//	
//	if(countries[0] == data[0]){
	countries =[req.query];
	console.log(countries)
		if(countries[1] ==req.query){
			console.log('ok')
		}else{
			console.log('noo...')
		}
		var citiesRef = db.collection('board');
		var query = citiesRef.where('brdCate', '==', '유럽').get().then(snapshot => {
			
			if (snapshot.empty) {
				console.log('No matching documents.');
				return;
			}
			var rows = [];
			snapshot.forEach(doc => {
				console.log(doc.id, '=>', doc.data());
				var childData = doc.data();
				childData.brddate = dateFormat(childData.brddate, "yyyy-mm-dd");
				rows.push(childData);
				
			});
			res.render('board2/boardList', {rows: rows});
			
		}).catch(err => {
			console.log('Error getting documents', err);
		});
//	}else if(countries[1] ==req.query){
//		var citiesRef = db.collection('board');
//
//        var query = citiesRef.where('brdCate', '==', '아시아').get().then(snapshot => {
//			
//			if (snapshot.empty) {
//				console.log('No matching documents.');
//				return;
//			}
//			var rows = [];
//			snapshot.forEach(doc => {
//				console.log(doc.id, '=>', doc.data());
//				var childData = doc.data();
//				childData.brddate = dateFormat(childData.brddate, "yyyy-mm-dd");
//				rows.push(childData);
//				
//			});
//			res.render('board2/boardList', {rows: rows});
//			
//		}).catch(err => {
//			console.log('Error getting documents', err);
//		});
//	}

   
})

router.get('/boardRead',function(req, res, next) {
    db.collection('board').doc(req.query.brdno).get()
        .then((doc) => {
            var childData = doc.data();
       
            childData.brddate = dateFormat(childData.brddate, "yyyy-mm-dd");
            res.render('board2/boardRead', {row: childData});
        })
        
});

router.get('/boardForm',upload.single('brdfile'),function(req,res,next){
    if (!req.query.brdno) { // new
        res.render('board2/boardForm', {row: ""});
        return;
    }
    
    // update
    db.collection('board').doc(req.query.brdno).get()
          .then((doc) => {
              var childData = doc.data();
              res.render('board2/boardForm', {row: childData});
          })
});

router.post('/boardSave',upload.single('brdfile'),function(req,res,next){
    console.log(req.body);
    var postData = req.body;
    if (!postData.brdno) {  // new
        postData.brddate = Date.now()
        postData.brdfile = req.file.originalname;//이름만 넣음..파일은  node서버에 저장..
       //console.log(req.file.originalname);
         console.log(req.file);
        var doc = db.collection("board").doc();
        postData.brdno = doc.id;
        doc.set(postData);
        console.log(req.file.filename)
    } else {                // update
        var doc = db.collection("board").doc(postData.brdno);
        doc.update(postData);
    }
    
  //파일정보
   
    res.redirect('boardList');
});

router.get('/boardDelete', function(req,res,next){
    db.collection('board').doc(req.query.brdno).delete();

    res.redirect('boardList');
});
router.get('/download',function(req,res,next){

   db.collection("board").doc(req.query.brdno).onSnapshot(function(doc){
                   console.log("Current data: ", doc.data());
                   var childData =doc.data();

               // var file = fs.readFileSync('/uploads/pdf/'+childData.brdfile +'-'+ file.filename,'utf-8');
                var file = fs.readFileSync('Z:/workspace3/again/uploads/pdf/'+childData.brdfile+'-'+'s','binary');
                // res.setHeader('Content-Length', file.length);
               //res.download(file,encodeURIComponent(path.basename(file)))
                res.write(file, 'binary');
                res.end();
                 return;
            }),function(error)  {
                console.log('Error getting documents', err);
            };
});
//router.get('/test',function(req,res,next){
//	 console.log(req.body.email);
//	 db.collection('board').doc(req.query.brdno).get()
//     .then((doc) => {
//         var childData = doc.data();
//    
//         childData.brddate = dateFormat(childData.brddate, "yyyy-mm-dd");
//         res.render('board2/boardRead', {row: childData});
//     })
     
//        
//		 data.brddate = dateFormat(childData.brddate, "yyyy-mm-dd");
//		 //var responseData = {'result':'data.brdno'}
////		 res.writeHead(200, {"Content-Type": "application/json"});
////		 res.json({'result':'data.brdno'});
//		 
//         res.render('board2/boardRead', {row: data});
//	 }),function(error)  {
//	     console.log('Error getting documents', err);
//	 };
	 
router.post('/test',function(req, res, next) {
	
	var citiesRef = db.collection('board');
	var query = citiesRef.where('brdCate', '==', '유럽').get().then(snapshot => {
		
		if (snapshot.empty) {
			console.log('No matching documents.');
			return;
		}
		var rows = [];
		snapshot.forEach(doc => {
			//console.log(doc.id, '=>', doc.data());
			var childData = doc.data();
			childData.brddate = dateFormat(childData.brddate, "yyyy-mm-dd");
			rows.push(childData);
		});
		var responseData = {'result':'dsadasds'}
		console.log(res);
		console.log(req.body.email);
		res.send(responseData); 
		 console.log('dsadsa');
	}).catch(err => {
		console.log('Error getting documents', err);
	});
        
});

//app.post('/api/create', (req, res) => {
//    (async () => {
//        try {
//          await db.collection('items').doc('/' + req.body.id + '/')
//              .create({item: req.body.item});
//          return res.status(200).send();
//        } catch (error) {
//          console.log(error);
//          return res.status(500).send(error);
//        }
//      })();
//  });
module.exports = router;
